my_str = 'aIbohPhoBiA'

#Make it suitable for caseless comparison
my_str = my_str.casefold()

#Reverse the string 
rev_str = reversed(my_str)

#Check if the string is equalto its reverse
if list(my_str) == list(rev_str):
    print("It's palindrome.")
else:
    print("It's'nt palindrome.")