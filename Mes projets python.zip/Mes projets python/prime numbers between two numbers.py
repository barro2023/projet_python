
#uncomment the following lines to take input from the user
A = int(input("Enter lower range: "))
B = int(input("Enter upper range: "))

print("Prime numbers between",A,"and",B,"are:")

for C in range(A, B+1):
    #print numbers are greater than  1
    if C > 1:
        for i in range(2, C):
            if (C % i)== 0:
                break
        print(C)
