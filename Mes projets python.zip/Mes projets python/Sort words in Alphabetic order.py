my_string = "Hello this Is an example With cased letters"

#uncomment to to take input from the user
my_string = input("Enter a string :")

#Breakdown the string into a list of words
words =my_string.split()

#sort the list
words.sort()
 
 #Display the sorted words
print("The sorted words are:")
for word in words:
    print(word)