E = {0, 2, 4, 6, 8};
N = {1, 2, 3, 4, 5};

#set union
print("\nUnion of E and N is",E | N)

#set intersection
print("\nIntersection of E and N is" ,E & N)

#set difference
print("\nDifference of E and N is",E - N)

#set symetric difference
print("\nSymetric difference of E and N is",E ^ N)