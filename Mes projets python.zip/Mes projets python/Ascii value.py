#uncomment to take character from user
c = input("Entrez un charactère:")

print("ASCII value of '" + c + "' is", ord(c)) 
