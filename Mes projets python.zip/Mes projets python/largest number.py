
#uncomment following lines to take three numbers from user
a = float(input("Enter first number:"))
b = float(input("Enter second number:"))
c = float(input("Enter third number:"))

if(a >= b) and (a >= c):
    largest = a
elif (b >= a) and (b >= c):
    largest = b
else:
    largest = c

print("The largest number between",a,",",b,"and",c,"is",largest)
