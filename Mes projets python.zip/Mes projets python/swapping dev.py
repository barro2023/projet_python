x = input('Enter value of x: ')
y = input('Enter value of y: ')

#Do the swapping
x, y = y, x

print('The value of x after swapping:',x)
print('The value of y after swapping:',y)