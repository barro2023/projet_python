a = input("Enter first number:")
b = input("Enter second number:")

sum = float(a) + float(b)

print('The sum of {0} and {1} is {2}'.format(a, b, sum))