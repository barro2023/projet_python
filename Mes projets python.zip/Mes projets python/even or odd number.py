a = int(input("Enter a number:"))
if (a % 2)== 0:
    print("{0} is Even".format(a))
else:
    print("{0} is Odd".format(a))