X = [[12,7],
    [4,5],
    [3,8]]

result = [[0,0,0],
         [0,0,0]]

#Iterate through rows
for i in range(len(X)):
    #Iterate for through colums
    for j in range(len(X[0])):
        result[j][i] = X[i][j]

for r in result:
    print(r)