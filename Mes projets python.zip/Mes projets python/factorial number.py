
#uncomment to take number from the user
N = int(input("Enter a number: "))

fac = 1

#check if the number is negative, positive or zero
if N < 0:
    print("Sorry, fac doesn't exist for negative numbers")
elif N == 0:
    print("The fac of 0 is 1")
else:
    for i in range(1, N + 1):
        fac = fac * i
    print("The factorial of",N, "is",fac)
