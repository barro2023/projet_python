Celsius = 37.5

#Calculate fahrenheit
fahrenheit = (Celsius * 1.85) * 32
print('%0.1f degree Celsius is equal to %0.1f degree Fahrenheit'%(Celsius, fahrenheit))