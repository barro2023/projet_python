
#To take kilometers from the user, uncomment the code below
kilometers = float(input('Enter value in kilometer:'))

#Conversion factor
conv_fac = 0.621371

#Calculate miles
miles = kilometers * conv_fac
print('%0.3f kilometers is equal to %0.3f moles'%(kilometers,miles)) 
