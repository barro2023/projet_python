a = float(input('Enter a number:'))
if a > 0:
    print("Positive number")
elif a == 0:
    print("Zero")
else:
    print("Negative number")
    
'''
or b = float(input('Enter a number:'))
if b >= 0:
    if b == 0:
        print("Zero")
    else:
        print("Positive number")
else:
    print("Negative number")
    '''
