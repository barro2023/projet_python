def print_factors(x):
    #This function take a number and print the factors
    print("The factors of",x,"are:")
    for i in range (1, x + 1):
        if x % i == 0:
            print(i)

#uncomment to take input from the user
x = int(input("Enter a number:"))

print_factors(x)