
#Take input from the user
a = int(input("Enter a number: "))

#Prime numbers are greater than 1
if a > 1:
    #Check for factors
    for i in range (2,a):
        if(a % i)== 0:
            print(a,"is not a prime number")
            #print(i,"times",a)
            break

    else:
        print(a,"is a prime number")
    ''' if input number is less than
    or equal to 1, it is not prime '''
else:
    print(a,"is not a prime number") 
