phrase = input("Enter a string:")
print(phrase[::-1])