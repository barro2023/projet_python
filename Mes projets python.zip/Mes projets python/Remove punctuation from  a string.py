punctuations = '''!()-[]{};:'"\,<>./?@#$%&*^'''

my_string = "Hello!!!,he said ---and went."

#To take input from the user 
my_string = input("Enter a string : ")

#Remove punctuation from the string
no_punct = ""
for char in my_string:
    if char not in punctuations:
        no_punct = no_punct + char

#Display the unpunctuated string
        print(no_punct)