
#to take input from the user
N = int(input("Display  multiplication table of? "))
#use for loop to iterate 10 times
for i in range(1, 11):
    print(N,'x',i,'=',N * i)
