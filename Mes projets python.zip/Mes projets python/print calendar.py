import calendar

#To ask month and year from the user
yy = int(input("Enter year:"))
mm = int(input("Enter month:"))

#display the calendar
print(calendar.month(yy, mm))
