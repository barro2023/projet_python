vowels = 'aeiou'

#Change this value for a different result
ip_str = "Hello, have you tried our tutorial section yet?"

#Uncomment to take input from the user
ip_str = input("Enter a string : ")

#Make it suitable for caseless comparisons
ip_str = ip_str.casefold()

#Make a dictionary with each vowel a key and value
count = {}.fromkeys(vowels,0)

#count the vowels
for char in ip_str:
    if char in count:
        count[char] += 1

print(count)