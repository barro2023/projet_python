#uncomment to take the input from the user
C = float(input('Enter a number:'))
C_sqrt = C ** 0.5
print('The square root of %0.3f is %0.3f' %(C, C_sqrt))
